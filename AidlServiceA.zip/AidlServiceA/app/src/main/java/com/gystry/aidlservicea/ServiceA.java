package com.gystry.aidlservicea;

import android.app.Service;

public class ServiceA extends Service {
}
